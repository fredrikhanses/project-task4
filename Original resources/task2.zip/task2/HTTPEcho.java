import java.net.*;
import java.io.*;

public class HTTPEcho {
    public static void main( String[] args) {
        // Your code here
    }
}

